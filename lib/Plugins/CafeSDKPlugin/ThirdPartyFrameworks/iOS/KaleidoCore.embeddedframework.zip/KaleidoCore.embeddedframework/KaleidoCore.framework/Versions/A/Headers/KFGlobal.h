//
//  KFGlobal.h
//  KaleidoCore
//
//  Created by Seungha on 2017. 6. 12..
//  Copyright © 2017년 NAVER. All rights reserved.
//

#ifndef KFGlobal_h
#define KFGlobal_h

#define EXPORT __attribute__((visibility("default")))

#endif /* KFGlobal_h */
