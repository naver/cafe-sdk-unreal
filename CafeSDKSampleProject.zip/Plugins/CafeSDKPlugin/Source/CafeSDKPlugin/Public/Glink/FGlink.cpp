// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.
#include "CafeSDKPluginPrivatePCH.h"
#include "FGlink.h"


const FString FGlink::NaverLoginClientId = "FvSG3PVQvg7mzjc5C5RG";//"197CymaStozo7X5r2qR5";
const FString FGlink::NaverLoginClientSecret = "Ye0epVI11r";//"evCgKH1kJL";
const int FGlink::CafeId = 26273615;//28290504;



FGlink::FGlink() {
    
}


void FGlink::executeArticlePost(int menuId, FString subject, FString content) {
    
}

void FGlink::executeArticlePostWithImage(int menuId, FString subject, FString content, FString filePath) {
    
}

void FGlink::executeArticlePostWithVideo(int menuId, FString subject, FString content, FString filePath) {
    
}